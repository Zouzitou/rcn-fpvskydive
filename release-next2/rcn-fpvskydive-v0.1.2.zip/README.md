# RCN FPV SkyDive

Safe, per-user Windows bridge for DJI RC-N controllers and FPV SkyDive. It exposes validated controller input as a virtual Xbox 360 controller.

> Status: early production scaffold. RC-N1 USB discovery and core safety primitives are implemented; driver installation, live DuML decoding, ViGEm validation, and RC-N2/RC-N3 protocol support require hardware validation before a release can claim `READY`.

## Design goals

- One PowerShell bootstrapper, isolated under `%LOCALAPPDATA%\\RCN-FPVSkyDive`.
- Protocol-port selection by positive USB/interface evidence; Debug ports are rejected.
- Neutral output on startup, stale data, reconnect, shutdown, and failed self-test.
- Pinned dependencies, structured diagnostics, idempotent repair, and explicit unsupported states.

See [ARCHITECTURE.md](ARCHITECTURE.md), [ACCEPTANCE.md](ACCEPTANCE.md), and [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md).

## Development

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.lock
\.venv\Scripts\python.exe -m pytest -q
```

## Installation

Run from a trusted checkout or a release-pinned URL in an elevated or non-elevated PowerShell terminal:

```powershell
irm https://example.invalid/rcn-fpv/bootstrap.ps1 | iex
```

The public release URL will replace the placeholder only after signed artifacts and SHA-256 manifests are published. The bootstrapper does not silently install an unverified driver.

## Commands

```powershell
rcn-fpv status
rcn-fpv diagnose
rcn-fpv start
rcn-fpv stop
rcn-fpv repair
rcn-fpv uninstall
```

## Security

Driver installation is an explicit, elevated operation and must verify provider, signature, and matching hardware IDs before `pnputil`. Diagnostic exports redact user names and absolute paths. No game configuration is edited while FPV SkyDive is running.
